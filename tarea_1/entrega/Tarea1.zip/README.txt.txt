Hay un sólo detalle:
new_controller.py no finaliza después de terminar todas las acciones, intenté varias cosas
pero no logré que se cerrará :( hay que hacer ctrl+c cuando termine todas las acciones.
(Gracias ROS2)